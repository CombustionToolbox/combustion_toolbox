% Standard Atmosphere Functions
% Version 2.3 .
